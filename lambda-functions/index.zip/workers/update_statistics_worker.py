import data_repository as dal
import os
import boto3

TOPIC_ARN = os.environ["TOPIC_ARN"]  # "chmury.website.images"

sns = boto3.client('sns')


def lambda_handler(event, context):
    dailyData = dal.update_statistics_and_get_daily_data()
    message = ["<table>",
               "<tr><th>Label</th><th>Count</th></tr>"
               ]
    for label in dailyData:
        message.append(f"<tr><td>{label}</td><td>{dailyData[label]}</td></tr>")
    message.append("</table>")

    msg = ""
    msg = msg.join(message)
    response = sns.publish(
        TopicArn=TOPIC_ARN,
        Message=msg,
    )

    print(response)
